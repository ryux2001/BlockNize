# BlockNize — Icono Android adaptativo

Diseño: monograma BN blanco (#FFFFFF), fondo negro (#000000).

## Archivos

- `blocknize_foreground.png`: primer plano transparente, 432x432. Usar en la pestaña Foreground Layer.
- `blocknize_background.png`: fondo negro, 432x432. Alternativamente escoger color #000000 en Background Layer.
- `blocknize_monochrome.png`: versión monocromática transparente, 432x432. Usar en Monochrome Layer.
- `blocknize_google_play_512.png`: base gráfica 512x512 para una futura ficha (revisar otros requisitos de publicación).
- `blocknize_vista_previa.png`: representación en máscara cuadrada redondeada y circular, para comprobar el recorte.

## Importar en Android Studio

1. Abrir el proyecto y seleccionar la vista Android.
2. Clic derecho en `app > res` -> `New` -> `Image Asset`.
3. `Icon Type`: `Launcher Icons (Adaptive and Legacy)`.
4. `Foreground Layer`: `Asset Type = Image` y elegir `blocknize_foreground.png`.
5. `Background Layer`: usar `Color = #000000` o la imagen `blocknize_background.png`.
6. `Monochrome Layer`: seleccionar `Image` y usar `blocknize_monochrome.png` (si la versión de Android Studio dispone de esta pestaña).
7. Nombre del recurso: `ic_launcher`. Revisar las vistas previas circular y cuadrada; ajustar Resize si fuese necesario, dejando un margen prudente.
8. `Next` > `Finish`, sobrescribiendo los iconos iniciales si el asistente lo propone.
9. En `AndroidManifest.xml`, dentro de `<application>`, confirmar:

```xml
android:icon="@mipmap/ic_launcher"
android:roundIcon="@mipmap/ic_launcher_round"
```

10. Ejecutar la app. Si el launcher conserva el icono antiguo por caché, quitar y volver a añadir su acceso directo o reinstalar la app en un dispositivo de pruebas.

## Notas

- No usar el PNG original con fondo negro como primer plano: la capa foreground requiere transparencia para que la máscara funcione correctamente.
- El tema de iconos de Android puede recolorear la capa monocromática según los ajustes del usuario. Ese comportamiento es independiente del acento violeta configurado dentro de BlockNize.
- Las capas adaptativas se diseñaron con un símbolo centrado dentro de la zona segura. El archivo fuente no es vectorial; para una edición precisa futura conviene redibujar el monograma en SVG o VectorDrawable.
